# XBAP default Applocker Bypass POC
A POC application whitelisting XBAP project. 

You should be able to run powershell commands by grabbing the files in the powershell/bin/Debug/ folder and running `presentationhost file:///path/to/files/powershell.xbap` or by double clicking the xbap file.

If you download the binary files from git hub you will need to remove the mark of the web from them before presentation host will execute them.

Checkout the blog post https://medium.com/@jpg.inc.au/pentesting-and-xbap-presentationhost-exe-applocker-bypass-8c87b2354cd4 

